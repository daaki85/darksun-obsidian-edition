# Merchant and stationary figure review

Open review.html locally to compare each proposal with the original and its Shattered Lands reference at the same pixel scale. Use the frame slider or arrow buttons to inspect individual poses. Select **All stored poses** to see frames outside the default script slot.

The 54 numbered folders contain review candidates. Each base.chunk replaces the corresponding BMP picture resource. Where present, combat.chunk is its CBMP resource. Each PNG uses the original frame extent and anchor. The original animation scripts are required. In-game and map-placement testing is pending.

The detached-human-merchants-unassigned folder is an NPC-only visual study. Keep it unassigned. The original shared figure 691 and approved player elf require separate resources before any NPC replacement can be integrated.
